File services implemented in Python during my masterthesis and used in my notebooks.<br>
Learn more by visiting my repository @[SSfSBT][https://github.com/SimonHegele/SSfSBT]